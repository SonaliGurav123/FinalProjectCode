package com.example.customerteam2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customerteam2.dao.CustomerDao;
import com.example.customerteam2.exception.CustomerNotFoundException;
import com.example.customerteam2.model.CustomerTeam2;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService 
{
	@Autowired
	CustomerDao customerDao;
	
	public String addCustomer(CustomerTeam2 customer) 
	{
		customerDao.save(customer);
		return "ADDED";
	}
	
	public List<CustomerTeam2> displayAllCustomers()
	{
		List<CustomerTeam2> customerList=customerDao.findAll();
		return customerList;
	}
	
	public CustomerTeam2 displayCustomerById(Integer customerId)  
	{
		Optional<CustomerTeam2> c1=customerDao.findById(customerId);
        return c1.orElseThrow(() -> new CustomerNotFoundException("Record not found with ID: " + customerId));

		
		
		//Optional<Customer> customerList=customerDao.findById(customerId);
		//return customerList.orElseThrow(()->new RuntimeException("User not found"));
		//return c1;
		//return c1;
		
	}
	
	
	
	public List<CustomerTeam2> displayCustomerByPlanId(Integer planId) 
	{
		List<CustomerTeam2> customerList=customerDao.findByPlanId(planId);
		
		    return customerList;
		
	}
	public List<CustomerTeam2> displayCustomerByStatus(String status)
	{
		List<CustomerTeam2> customerList=customerDao.findByStatus(status);
		return customerList;
	}
	
	public List<CustomerTeam2> displayCustomerByPhoneNo(String phoneNo)
	{
		List<CustomerTeam2> customerList=customerDao.findByPhNo(phoneNo);
		return customerList;
	}
	
}
	
	
	/*public Customer getCustomerByPlanId(Integer planId)
	{
		List<Customer> customerList=customerDao.findById(planId);
		return customerList;
	}
	
	
	/*public List<Customer> getCustomerByPlanId(Integer planId)
	{
		List<Customer> customerList=customerDao.findAll();
		return customerList;
	}*/
	
	
	

	/*
	public List<Customer> getCustomerByphNo(Integer PhNo)
	{
		List<Customer> customerList=customerDao.findAll();
		return customerList;
	}
	*/
	




/*public List<Customer> getCustomerByCustomerIdDetails(Integer customerId)
{
	List<Customer> customerList=customerDao.findAll();
	return customerList;
}*/