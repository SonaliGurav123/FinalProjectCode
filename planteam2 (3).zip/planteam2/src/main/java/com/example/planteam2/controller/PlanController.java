package com.example.planteam2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.planteam2.model.PlanTeam2;
import com.example.planteam2.service.PlanService;

@RestController
public class PlanController {
	@Autowired
	PlanService planService;
	
	@PostMapping("/addPlan")
	public String addDetails(@RequestBody PlanTeam2 p1)
	{
		return planService.addPlan(p1);
	}
	
	@GetMapping("/getAllPlans")
	public List<PlanTeam2> getAllPlan()
	{
		List<PlanTeam2> p1=planService.getAll();
		return p1;
	}
  @GetMapping("/getPlanByName/{pname}")
	public List<PlanTeam2> getDetailsByName(@PathVariable String pname)
	{
		return planService.getPlanByPname(pname);
	}
  
  @GetMapping("/getPlanPrice/{price}")
 	public List<PlanTeam2> getByPrice(@PathVariable Integer price)
 	{
 		return planService.getPlanBypPrice(price);
 	}
  @GetMapping("/getPlanBydays/{days}")
	public List<PlanTeam2> getByDays(@PathVariable Integer days)
	{
		return planService.getPlanBypDays(days);
	}
  @GetMapping("/getPlanByType/{typeOfPlan}")
	public List<PlanTeam2> getByType(@PathVariable String typeOfPlan)
	{
		return planService.findBytypeOfPlan1(typeOfPlan);
	}
}
