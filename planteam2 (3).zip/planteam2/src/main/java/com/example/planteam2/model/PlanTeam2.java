package com.example.planteam2.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class PlanTeam2 {
	@Id
	Integer pid;
	@Column
	String pname;
	Integer price;
	Integer noOfCalls;
	Integer dataPerDay;
	Integer noOfMsg;
	Integer noOfDays;
	String typeOfPlan;
	public PlanTeam2()
	{
		
	}
	
	public PlanTeam2(Integer pid, String pname, Integer price, Integer noOfCalls, Integer dataPerDay, Integer noOfMsg,
			Integer noOfDays,String typeOfPlan) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.noOfCalls = noOfCalls;
		this.dataPerDay = dataPerDay;
		this.noOfMsg = noOfMsg;
		this.noOfDays = noOfDays;
		this.typeOfPlan=typeOfPlan;
	}

	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Integer getNoOfCalls() {
		return noOfCalls;
	}
	public void setNoOfCalls(Integer noOfCalls) {
		this.noOfCalls = noOfCalls;
	}
	public Integer getDataPerDay() {
		return dataPerDay;
	}
	public void setDataPerDay(Integer dataPerDay) {
		this.dataPerDay = dataPerDay;
	}
	public Integer getNoOfMsg() {
		return noOfMsg;
	}
	public void setNoOfMsg(Integer noOfMsg) {
		this.noOfMsg = noOfMsg;
	}
	public Integer getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(Integer noOfDays) {
		this.noOfDays = noOfDays;
	}
	
	public String getTypeOfPlan() {
		return typeOfPlan;
	}

	public void setTypeOfPlan(String typeOfPlan) {
		this.typeOfPlan = typeOfPlan;
	}

	@Override
	public String toString() {
		return "PlanTeam [pid=" + pid + ", pname=" + pname + ", price=" + price + ", noOfCalls=" + noOfCalls
				+ ", dataPerDay=" + dataPerDay + ", noOfMsg=" + noOfMsg + ", noOfDays=" + noOfDays + typeOfPlan+"]";
	}
	
}
