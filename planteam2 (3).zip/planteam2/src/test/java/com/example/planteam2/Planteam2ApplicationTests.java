package com.example.planteam2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Planteam2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
