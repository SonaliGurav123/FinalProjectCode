package com.example.callhistoryteam2.dao;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.callhistoryteam2.model.Call;



@Repository
//@Component
public interface CallDao  extends JpaRepository<Call,Integer>
{

List<Call> getCallByfromId(@Param("fromId")Integer fromId);
List<Call> getCallBytoId(@Param("toId")Integer tid);
List<Call> getCallBytotalTime(@Param("totalTime")Float totalTime);
List<Call> getCallByplanId(@Param("planId")Integer planId);

/*@Query("select sum(totalTime) from Call where planId=1 or planId=2 or planId=3 and fromId=:fromId group by fromId;")
Integer getTotalAmount(@Param("fromId")Integer fromId);
*/
@Query("select sum(totalTime) from Call where (planId=1 or planId=2 or planId=3) and fromId=:fromId group by fromId")
Integer getTotalAmount(@Param("fromId")Integer fromId);
}

