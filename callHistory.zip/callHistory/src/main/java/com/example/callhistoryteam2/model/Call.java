package com.example.callhistoryteam2.model;
import java.time.Duration;
import java.time.LocalDateTime;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PostLoad;

@Entity
public class Call {
@Id
Integer callId;
Integer fromId;
Integer toId;
LocalDateTime startTime;
LocalDateTime endTime;
Float totalTime;
Integer planId;
public Call(){
}

public Call(Integer callId, Integer fromId, Integer toId,LocalDateTime startTime,
		LocalDateTime endTime, Float totalTime, Integer planId) {
	super();
	this.callId = callId;
	this.fromId = fromId;
	this.toId = toId;
	this.startTime = startTime;
	this.endTime = endTime;
	//totalTime =calculateTotalTime(startTime,endTime);
	Duration d=Duration.between(this.startTime, this.endTime);
	this.totalTime=(float)d.toMinutes();
	this.planId = planId;
}
@Override
public String toString() {
	return "Call [callId=" + callId + ", fromId=" + fromId + ", toId=" + toId + ", startTime="
			+ startTime + ", endTime=" + endTime + ", totalTime=" + totalTime + ", planId=" + planId + "]";
}
 float calculateTotalTime(LocalDateTime startTime,LocalDateTime endTime)
{System.out.println("start time "+startTime);
	if(startTime!=null && endTime!=null)
	{
		Duration d=Duration.between(startTime, endTime);
		return (float)d.toMinutes();
	}
	return 0.0f;
}

@PostLoad
public void postLoad()
{
	this.totalTime=calculateTotalTime(this.startTime,this.endTime);
}
public Integer getCallId() {
	return callId;
}
public void setCallId(Integer callId) {
	this.callId = callId;
}
public Integer getFromId() {
	return fromId;
}
public void setFromId(Integer fromId) {
	this.fromId = fromId;
}
public Integer getToId() {
	return toId;
}
public void setToId(Integer toId) {
	this.toId = toId;
}
public LocalDateTime getStartTime() {
	return startTime;
}
public void setStartTime(LocalDateTime startTime) {
	this.startTime = startTime;
	//this.totalTime=calculateTotalTime(this.startTime,endTime);
}
public LocalDateTime getEndTime() {
	return endTime;
}
public void setEndTime(LocalDateTime endTime) {
	this.endTime = endTime;
	//this.totalTime=calculateTotalTime(startTime,this.endTime);
}
public Float getTotalTime() {
	return totalTime;
}
public void setTotalTime(Float totalTime) {
	this.totalTime = totalTime;
}
public Integer getPlanId() {
	return planId;
}
public void setPlanId(Integer planId) {
	this.planId = planId;
}
}

